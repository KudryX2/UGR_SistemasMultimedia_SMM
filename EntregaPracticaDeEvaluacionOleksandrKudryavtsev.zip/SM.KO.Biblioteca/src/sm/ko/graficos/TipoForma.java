/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.ko.graficos;

/**
 *
 * @author Kudry
 */
public enum TipoForma {
    LIBRE,PUNTO,LINEA,CURVA,RECTANGULO,ELIPSE,SEMICIRCULO;
}
